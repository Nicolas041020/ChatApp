CREATE DATABASE Chat;
USE Chat;

CREATE TABLE Usuarios(
	Nickname varchar(20),
	IP varchar (20),
	Estado boolean,
	PRIMARY KEY(Nickname)
);

CREATE TABLE Mensaje(
	Id_Mensaje int AUTO_INCREMENT PRIMARY KEY,
	Contenido varchar(225),
	NicknameEmisor varchar(20),
	NicknameReceptor varchar(20),
	FOREIGN KEY(NicknameEmisor) REFERENCES Usuarios(Nickname),
	FOREIGN KEY(NicknameReceptor) REFERENCES Usuarios(Nickname)
);

CREATE TABLE Contactos(
	NicknameEmisor varchar(20),
	NicknameReceptor varchar(20),
	FOREIGN KEY(NicknameEmisor) REFERENCES Usuarios(Nickname),
	FOREIGN KEY(NicknameReceptor) REFERENCES Usuarios(Nickname),
	PRIMARY KEY (NicknameEmisor, NicknameReceptor)
);